# Orator

DIY ChatGPT智能音箱(随视频教程更新中)
视频教程链接：https://space.bilibili.com/452098958

